
package agenda;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

public class CuadroActividad 
{
    private String numAct;
    
    public CuadroActividad()
    {
        
    }
    public CuadroActividad(String nu)
    {
        numAct=nu;
    }
    public String Numero()
    {
        return numAct;
    }
    public void editarNum(String n)
    {
        numAct=n;
    }
    public void GuardarString(RandomAccessFile a) throws IOException
    {
        a.writeUTF(numAct);
    }
    public void CargarString(RandomAccessFile a) throws IOException
    {
        numAct=a.readUTF();
    }
    public void adicionarAct(String archivoAct, CuadroActividad Act)  throws IOException
    {
        File archivoAv=new File(archivoAct);
        RandomAccessFile filez = new RandomAccessFile(archivoAct, "rw");
        
        if (!archivoAv.exists())
        {
            archivoAv.createNewFile();
            filez.seek(0);
            Act.GuardarString(filez);
            filez.close();
        }
        else
        {
            filez.seek(0);
            Act.GuardarString(filez);
            filez.close();
        }
    }
    public String recuperarAct(String ArchivoAct) throws IOException
    {
        CuadroActividad Act=new CuadroActividad();
        File f=new File(ArchivoAct);
        RandomAccessFile filez=null;
        if(f.exists())
        {
            filez=new RandomAccessFile(f,"rw");
            Act.CargarString(filez);
            filez.close();
        }
        return Act.Numero();
    }
}
