
package agenda;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Scanner;


public class Alarma 
{
    private String nameAlarm;
    private String nombreAct;
    private Fecha fechaAlarma;
    private HoraAlarma horaAlarma;
    
    public Alarma()
    {
        
    }
    public Alarma(String na, String n, Fecha f, HoraAlarma h)
    {
        nameAlarm=na;
        nombreAct=n;
        fechaAlarma=f;
        horaAlarma=h;
    }
    public String nameAlarma()
    {
        return nameAlarm;
    }
    public void editarNombreAlarma(String n)
    {
        nameAlarm=n;
    }
    public String nombreAct()
    {
        return nombreAct;
    }
    public void editarNombreAct(String n)
    {
        nombreAct=n;
    }
    public Fecha fechaA()
    {
        return fechaAlarma;
    }
    public void editaFecha(Fecha f)
    {
        fechaAlarma=new Fecha(f.diaFecha(),f.mesFecha(),f.anhoFecha());
    }
    public HoraAlarma horaAlarm()
    {
        return horaAlarma;
    }
    public void editarHoraAlarm(HoraAlarma d)
    {
        horaAlarma=new HoraAlarma(d.horaA(),d.minA());
    }
    public void mostrarDatos()
    {
        System.out.println ("\nNombre de la alarma: "+nameAlarm);
        System.out.println ("Nombre de la actividad: "+nombreAct);
        System.out.println ("Fecha de la alarma: "+fechaAlarma.diaFecha()+"/"+fechaAlarma.mesFecha()+"/"+fechaAlarma.anhoFecha());
        System.out.println("Hora de la alarma: "+horaAlarma.horaA()+":"+horaAlarma.minA());
    }
    public void guardarAlarma(RandomAccessFile archivo) throws IOException 
    {
        archivo.writeUTF(nameAlarm);       
        archivo.writeUTF(nombreAct);          
        archivo.writeInt (fechaAlarma.diaFecha());        
        archivo.writeInt (fechaAlarma.mesFecha());
        archivo.writeInt (fechaAlarma.anhoFecha());
        archivo.writeInt (horaAlarma.horaA());        
        archivo.writeInt (horaAlarma.minA());
    }
    
    public void recuperarAlarma(RandomAccessFile archivo) throws IOException 
    {   
        int df,mf,af,h,m;
        nameAlarm= archivo.readUTF();       
        nombreAct= archivo.readUTF();     
        df= archivo.readInt();       
        mf = archivo.readInt();       
        af = archivo.readInt();       
        fechaAlarma = new Fecha (df, mf, af);
        h = archivo.readInt();       
        m = archivo.readInt();              
        horaAlarma = new HoraAlarma (h, m);
    }
     public void adicionarAlarma(String archivoAlarma, Alarma a)  throws IOException
    {
        File archivoA=new File(archivoAlarma);
        RandomAccessFile filez = new RandomAccessFile(archivoAlarma, "rw");
        if (!archivoA.exists())
        {
            archivoA.createNewFile();
            filez.seek(0);
            a.guardarAlarma(filez);
            filez.close();
        }
        else
        {
            filez.seek(0);
            a.guardarAlarma(filez);
            filez.close();
        }
    }
}
