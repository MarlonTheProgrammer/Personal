package agenda;

public class Fecha
{
    private int dia;
    private int mes;
    private int anho;

    public Fecha()
    {
        
    }
    public Fecha(int d, int m, int a)
    {
        dia=d;
        mes=m;
        anho=a;
    }
    public int diaFecha()
    {
        return dia;
    }
    public void editarDia(int d)
    {
        dia=d;
    }
    public int mesFecha()
    {
        return mes;
    }
    public void editarMes(int m)
    {
        mes=m;
    }
    public int anhoFecha()
    {
        return anho;
    }
    public void editarAnho(int a)
    {
        anho=a;
    }
}
