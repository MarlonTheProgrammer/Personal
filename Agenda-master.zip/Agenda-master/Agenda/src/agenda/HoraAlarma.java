
package agenda;


public class HoraAlarma {
    private int hora;
    private int min;
    
    public HoraAlarma()
    {
        
    }
    public HoraAlarma(int h, int m)
    {
        hora=h;
        min=m;
    }
    public int horaA()
    {
        return hora;
    }
    public void editarHora(int h)
    {
        hora=h;
    }
    public int minA()
    {
        return min;
    }
    public void editarMin(int m)
    {
        min=m;
    }
}
